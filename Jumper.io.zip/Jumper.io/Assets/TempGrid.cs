﻿
///Mutlaka sil.

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TempGrid : MonoBehaviour
{

    public GameObject pre;

    public float x, y;
    public int sizeX,sizeY;

    void Start()
    {
        CreateGrid();
    }

    void CreateGrid()
    {

        Vector3 pos;

        for (int i = 0; i < sizeY; i++)
        {
            for (int j = 0; j < sizeX; j++)
            {
                GameObject temp = Instantiate(pre);
                pos = new Vector3(j * x, 0, i * y);
                if (i % 2 == 1)
                {
                    pos.x += x/2;
                }
                temp.transform.position = pos;

            }    
        }


    }
}
