﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



/// <summary>
/// Topları random circle direction kullanak belirli bir akışla hareket ettir.
/// Assassin ball oluştur
/// Eğer player çok buyukse assassin'ler playeri öldürmeyi denesin
/// </summary>
public class BallAIController : MonoBehaviour
{
    
}
