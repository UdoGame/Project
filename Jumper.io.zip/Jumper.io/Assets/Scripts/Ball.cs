﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{

    public int rowCoordinate=0;
    public int columnCoordinate=0;
    public BallStat ballStat = BallStat.OnGround;

    //public AnimationCurve animationCurve;
    //public float animDuration;

    private GridManager _gridManager;
    private Rigidbody rigidbody;
    private bool createWave = false;

    private void Start()
    {
        _gridManager = GridManager.Instance;
        rigidbody = GetComponent<Rigidbody>();
    }

    private void Update() // cahnge to lat eor fixed
    {
        CalculateGroundCoordinate();
        IsJumped();
    }


    private void CalculateGroundCoordinate()
    {
        if (ballStat == BallStat.Jumping)
        { 
            return;
        }
        float xPos = transform.position.x;
        float zPos = transform.position.z;
        int column = (int)Mathf.Round((Mathf.Sqrt(3) / 3f * xPos) + (1f / 3f * zPos));
        int row = (int)Mathf.Round(0f - (2f / 3f * zPos));

        if (columnCoordinate != column || rowCoordinate != row)
        {
            _gridManager.RemoveBallOnTheHexagon(columnCoordinate, rowCoordinate,this);
            columnCoordinate = column;
            rowCoordinate = row;
            _gridManager.AddBallOnTheHexagon(columnCoordinate, rowCoordinate, this); 
        }
        if (createWave) /// Bu sekilde calısması bile muzice //DEgistir
        {
            createWave = false;
            _gridManager.CreateWaveEffect(columnCoordinate, rowCoordinate, this);
        }

    }

    private void IsJumped()     //Farklıbir yol bul. Sorun çıkaracaktır.
    {
        if (Mathf.Abs(rigidbody.velocity.y) > 0.15f)
        {
            ballStat = BallStat.Jumping;
        }
        else  if(createWave)
        {
            ballStat = BallStat.OnGround;
        }
    }

    public void JumpBall(float jumpForce)
    {
        if (ballStat != BallStat.Jumping)
        {
            ballStat = BallStat.Jumping;
            _gridManager.RemoveBallOnTheHexagon(columnCoordinate, rowCoordinate, this);
            rigidbody.GetComponent<Rigidbody>().AddForce(Vector3.up * jumpForce);
            createWave = true;
        }

    }
    
    public void AddForce(Vector3 force)
    {
        if (ballStat == BallStat.OnGround)
        {
            rigidbody.AddForce(force);
        }
    }
     

}
