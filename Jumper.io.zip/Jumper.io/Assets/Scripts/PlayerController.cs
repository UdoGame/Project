﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// Input Manager'dan input al. Ball'ı kontrol et. 
/// 
/// </summary>
public class PlayerController : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
