﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Ball", menuName = "Ball/Ball Data")]  

///Ball'ları listede tut. AI oluştur.
public class BallData : ScriptableObject
{
    public string name;
    public Material material;
    public Color color;

}
