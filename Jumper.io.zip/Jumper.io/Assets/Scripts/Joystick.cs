
//Deneme scripti. Duzeltilmsi gereken �ok yer var. Mutaka yeniden yaz

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Joystick : MonoBehaviour {
    
	public Transform player;
	public float speed = 5.0f;
	private bool touchStart = false;
	private Vector2 pointA;
	private Vector2 pointB;

	public Transform circle;
	public Transform outerCircle;
     

    /// <summary>
    /// Bu �ekilde olmaz. Mutlaka d�zeltilmeli. Dikkatttttttttttttttt
    /// </summary>
	void Update () {
		if(Input.GetMouseButtonDown(0)){
			pointA = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, Camera.main.transform.position.z));

			circle.transform.position = pointA ;
			outerCircle.transform.position = pointA ;
			circle.GetComponent<SpriteRenderer>().enabled = true;
			outerCircle.GetComponent<SpriteRenderer>().enabled = true;
		}
		if(Input.GetMouseButton(0)){
			touchStart = true;
			pointB = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, Camera.main.transform.position.z));
		}
		else if (Input.GetMouseButtonUp(0))
		{
			player.GetComponent<Ball>().JumpBall(500);
			touchStart = false;
		}
	}

    //Yanl�� yaz�lm��. Mutlaka d�zelt
	private void FixedUpdate(){
		if(touchStart){
			Vector2 offset = pointB - pointA;
			Vector2 direction = Vector2.ClampMagnitude(offset, 1.0f);
			MoveCharacter(direction);

			circle.transform.position = new Vector2(pointA.x + direction.x, pointA.y + direction.y);
		}else{
			circle.GetComponent<SpriteRenderer>().enabled = false;
			outerCircle.GetComponent<SpriteRenderer>().enabled = false;
		}

	}

    //Bari bunu d�zelt
	private void MoveCharacter(Vector2 direction){ 
		Vector3 dir = new Vector3(direction.x, 0, direction.y);
		player.GetComponent<Ball>().AddForce(dir * speed);  //Player contoller�n input almas�, ball'� kontrol etmesi gerek
        //Bu �ekilde olmaz
	}
}