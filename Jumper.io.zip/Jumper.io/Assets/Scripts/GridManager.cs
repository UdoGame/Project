﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Zenject;

/// <summary>
/// Hesaplamalar düzgün çalışıyor.
/// Sorun yok.
/// Mutlaka kontrol et.
/// 
/// ////////////////////////////////Bu şekilde gönderme
/// </summary>
public class GridManager : Singleton<GridManager>
{
    public GameObject gridElementPrefab;
    public int gridPoolSizeX;
    public int gridPoolSizeZ;

    public float elementSize = 1f; //change name

    private float width;
    private float height;
    private float horizontalSpace;
    private float verticalSpace;


    private PoolManager _poolManager;

    private List<HexagonalGridElement> gridElementList = new List<HexagonalGridElement>();

    [Inject]
    private void Installer(PoolManager poolManager)
    {
        _poolManager = poolManager;
    }

    private void Start()
    {
        width = Mathf.Sqrt(3) * elementSize;
        height = 2f * elementSize;
        horizontalSpace = width;
        verticalSpace = height * 3f / 4f;

    }

         
    public void CreateGrid()
    {
        gridElementList = _poolManager.GetListFromDictionary(gridElementPrefab).ConvertAll(x => x.GetComponent<HexagonalGridElement>());
        Vector3 position = Vector3.zero;

        int q = 0;  //column
        int r = 0;  //row

        for (int i = 0; i < gridPoolSizeZ; i++)
        {
            for (int j = 0; j < gridPoolSizeX; j++)
            {
                q = j - (i / 2);
                r = i;
                position = GetPositionWithCoordinate(q, r);
                gridElementList[i * gridPoolSizeX + j].SetCoordinates(r, q);
                _poolManager.Spawn(gridElementPrefab,transform , position);
            }
        }


    }

    public void AddBallOnTheHexagon(int q, int r,Ball ball)
    {
        int index = r * gridPoolSizeX + (q + r / 2);
        gridElementList[index].AddBallIntoList(ball);

    }
    public void RemoveBallOnTheHexagon(int q, int r, Ball ball)
    {
        int index = r * gridPoolSizeX + (q + r / 2);
        gridElementList[index].RemoveBall(ball);

    }
    private Vector3 GetPositionWithCoordinate(int q, int r)
    {
        Vector3 position = Vector3.zero;

        position.x = (Mathf.Sqrt(3) * q) + (Mathf.Sqrt(3) / 2f * r );
        position.z = (-1f) * 3f / 2f * r;

        return position;
    
    }

    public void CreateWaveEffect(int q,int r,Ball ball)
    {
        int index = r * gridPoolSizeX + (q + r / 2);
        gridElementList[index].ChangeColor(Color.red);/// Deneme. Topun rengi alınmalı.
    }

     
}
