﻿using System;
using UnityEngine;

//Sorun yok .OK
[Serializable]
    public class PoolableObject
    {     
        public GameObject itemPrefab; 
        public int poolSize; 
        public Transform parent = null;
        public bool activeAtStart = true;


        public PoolableObject(GameObject itemPrefab, int poolSize,Transform parent,bool activeAtStart)
        {
            this.itemPrefab = itemPrefab;
            this.poolSize = poolSize;
            this.parent = parent;
            this.activeAtStart = activeAtStart;
        }

        public PoolableObject(GameObject itemPrefab, int poolSize, bool activeAtStart)
        {
            this.itemPrefab = itemPrefab;
            this.poolSize = poolSize;
            GameObject tempParent = new GameObject();
            tempParent.name = itemPrefab.name + " Parent";
            this.parent = tempParent.transform;
            this.activeAtStart = activeAtStart;
        }
    
    } 