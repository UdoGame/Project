﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Zenject;

// Şu an sadece basitce oyunu başlatıyor. Mutlaka düzenle. 
// Buş şekilde gönderme.
//Dikkatttw
public class GameManager : MonoBehaviour
{
    private PoolManager _poolManager;
    private GridManager _gridManager;

    [Inject]
    private void Installer(PoolManager poolManager, GridManager gridManager)
    {
        _poolManager = poolManager;
        _gridManager = gridManager;
    }


    private void Start()
    {
        InitializePooling();

    }


    private void InitializePooling()
    {
        GameObject gridElementPrefab = _gridManager.gridElementPrefab;
        int gridPoolSize = _gridManager.gridPoolSizeX * _gridManager.gridPoolSizeZ;

        PoolableObject gridPoolObj = new PoolableObject(gridElementPrefab, gridPoolSize, false);
        _poolManager.Pool(gridPoolObj);
        CreateGridSystem();

         
    }

    private void CreateGridSystem()
    {
        _gridManager.CreateGrid();
    }


}
