﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine; 
using Zenject;

//Sorun yok
namespace Injection
{
    /// <summary>
    /// Game Installer = using for injection
    /// </summary>
    public class GameInstaller : MonoInstaller
    {
         
        public PoolManager _poolManager;
        public GameManager _gameManager;
        public GridManager _gridManager;

        public override void InstallBindings()
        {
            Container.BindInstance<PoolManager>(_poolManager);
            Container.BindInstance<GameManager>(_gameManager);
            Container.BindInstance<GridManager>(_gridManager); 
        }


    }
}
