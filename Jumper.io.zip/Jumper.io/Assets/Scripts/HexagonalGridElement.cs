﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Renkler kontrol edilmeli
/// </summary>
public class HexagonalGridElement : MonoBehaviour
{
    public int rowIndex;
    public int columnIndex;
    public List<Ball> ballListOnMe = new List<Ball>();

    public void SetCoordinates(int row, int column)
    {
        rowIndex = row;
        columnIndex = column;
    }

    public void AddBallIntoList(Ball ball)
    {
        if (!ballListOnMe.Contains(ball))
        {
            ballListOnMe.Add(ball);
        }
    }

    public void RemoveBall(Ball ball)
    {
        if (ballListOnMe.Contains(ball))
        {
            ballListOnMe.Remove(ball);
        }
    }

    public void ChangeColor(Color color)
    {
        gameObject.GetComponent<Renderer>().material.color = color;
    }

}
