namespace Zenject
{
    public interface IAnimatorMoveHandler
    {
        void OnAnimatorMove();
    }
}

