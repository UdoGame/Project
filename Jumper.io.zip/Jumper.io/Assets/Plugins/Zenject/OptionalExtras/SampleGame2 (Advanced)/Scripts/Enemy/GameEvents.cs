namespace Zenject.SpaceFighter
{
    public struct PlayerDiedSignal
    {
    }

    public struct EnemyKilledSignal
    {
    }
}
