using UnityEngine;

namespace Zenject.Asteroids
{
    public class BrokenShipFactory : PlaceholderFactory<Transform>
    {
    }
}


